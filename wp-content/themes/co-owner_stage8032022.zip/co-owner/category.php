<?php
/**
 * The template for displaying Category Archive pages
 *
 * Please see /external/bootstrap-utilities.php for info on CoOwner::get_template_parts()
 *
 * @package 	WordPress
 * @subpackage 	Co-Owner
 * @autor 		TechXperts
 */
get_header();
?>


<?php if ( have_posts() ): ?>
	<h1>
		<?php echo __('Category Archive:', 'co_owner'); ?> <?php echo single_cat_title( '', false ); ?>
	</h1>
	<ul class="list-unstyled">
		<?php while ( have_posts() ) : the_post(); ?>
		<li>
			<h2>
				<a href="<?php esc_url( the_permalink() ); ?>" title="<?php the_title(); ?>" rel="bookmark">
					<?php the_title(); ?>
				</a>
			</h2>
			<time datetime="<?php the_time( 'Y-m-d' ); ?>" pubdate>
				<?php the_date(); ?> <?php the_time(); ?>
			</time>
			<?php comments_popup_link(__('Leave a Comment', 'co_owner'), __('1 Comment', 'co_owner'), __('% Comments', 'co_owner')); ?>
			<?php the_content(); ?>
		</li>
		<?php endwhile; ?>
	</ul>
<?php else: ?>
	<h1>
		<?php echo __('No posts to display in', 'co_owner'); ?> <?php echo single_cat_title( '', false ); ?>
	</h1>
<?php endif; ?>

<?php get_footer(); ?>
