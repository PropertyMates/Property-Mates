<div class="modal fade default-modal-custom" id="alert-model" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row text-center">
                    <div class="col-sm-12 col-12 pt-4 pb-3">
                        <?php echo co_owner_get_svg('big-verified') ?>
                    </div>
                    <div class="col-sm-12 col-12 text-center pt-20px">
                        <h6 id="message">Email ID Updated Successfully.</h6>
                    </div>
                    <div class="col-sm-12 col-12 text-center pt-20px">
                        <a href="#" class="text-orange" data-bs-dismiss="modal">Thank You</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
