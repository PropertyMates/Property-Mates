<?php

class CoOwner_Reports extends CoOwner_Model
{
    public static $table = CO_OWNER_REPORTS_TABLE;

}
