    <script type="text/template" id="tpl-html">
        <div class="cancel_alert_modal">
		  
        </div>
    </script>