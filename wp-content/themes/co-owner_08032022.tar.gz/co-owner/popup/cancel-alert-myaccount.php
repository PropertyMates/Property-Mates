    <script type="text/template" id="cancel_alert">
        <div class="cancel_alert_container">
          <div class="title">Are you sure you want to leave this page?</div>
		  <div class="sub_title">You have unsaved data</div>
        </div>
    </script>