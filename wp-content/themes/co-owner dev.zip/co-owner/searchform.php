<form class="form-inline" id="searchform" role="search" method="get" action="<?php echo home_url( '/' ); ?>">
    <div class="input-group">
        <input class="form-control" id="s" name="s" type="text" placeholder="<?php echo __('Search', 'co_owner'); ?>">
        <button class="btn btn-outline-success" type="submit">
            <?php echo __('Search', 'co_owner'); ?>
        </button>
    </div>
</form>
