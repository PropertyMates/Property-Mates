<div class="my-listings-left h-100 py-40px">
    <ul>
        <li class="<?php echo is_page(CO_OWNER_MY_LISTINGS_PAGE) ? 'active' : null?>"><a href="<?php echo home_url('my-listings');?>">My Listings</a></li>
        <li class="<?php echo is_page(CO_OWNER_MY_ACCOUNT_VERIFICATION) ? 'active' : null?>"><a href="<?php echo home_url('my-account-verification');?>">My Account Verification</a></li>
        <li class="<?php echo is_page(CO_OWNER_MY_ACCOUNT_PAGE) ? 'active' : null?>"><a href="<?php echo home_url('my-account');?>">My Account</a></li>
        <li class="<?php echo is_page(CO_OWNER_MY_CONNECTIONS_PAGE) ? 'active' : null?>"><a href="<?php echo home_url('my-connections');?>">My Connections</a></li>
        <li class="<?php echo is_page(CO_OWNER_MY_NOTIFICATION_SETTINGS) ? 'active' : null?>"><a href="<?php echo home_url('my-notification-settings');?>">Notification Settings</a></li>
    </ul>
    <a class="d-block my-5" href="<?php echo wp_logout_url(home_url('/')); ?>">Logout</a>
</div>
