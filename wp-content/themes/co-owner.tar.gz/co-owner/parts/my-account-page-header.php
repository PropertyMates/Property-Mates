<div class="main-section bg-grey public-title for-my-list py-20px">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 inner-section-grey list-view-title">
                <div class="title-area pb-0">
                    <h3 class="d-flex align-items-center">
                        <span class="pe-2">
                            <?php
                            $user_id = get_current_user_id();
                            echo get_user_full_name($user_id);
                            if(get_user_shield_status($user_id)){
                                echo "&nbsp;<span class='user-shield-tooltip'>".co_owner_get_svg('big_shield')."</span>";
                            }
                            ?>
                        </span>

                        <div class="ms-auto">
                            <div class="custom-btn-area">
                                <a href="#" class="btn btn-black-text me-2">Why Upgrade?</a>
                                <a href="#" class="btn btn-orange btn-big rounded-pill" data-bs-target="#plan-modal" data-bs-toggle="modal">Upgrade</a>
                            </div>
                        </div>
                    </h3>
                </div>
            </div>
        </div>
    </div>
</div>
