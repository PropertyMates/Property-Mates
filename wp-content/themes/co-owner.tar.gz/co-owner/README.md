Bootstrap on WordPress
===========
Bootstrap on WordPress is a blank bootstrap 5 ready WordPress theme.

For the full documentation visit the [Bootstrap on WordPress](https://bootstraponwordpress.com/) website.
