<div class="center-area">
    <div class="p-4 m-4 text-center">
        <img src="<?php echo CO_OWNER_THEME_DIR_URI.'/images/page-not-found.png'; ?>" alt=""><br>
        <h4 class="h4 mt-4"> <a href="<?php echo home_url(); ?>">Go Home</a></h4>
    </div>
</div>
